const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/App-YvhEHE9b.js","assets/supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__-CbMmPqiQ.js","assets/_commonjsHelpers-DWwsNxpa.js","assets/supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__-ebOofBfC.js","assets/App-BrqpL1JY.css"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-ClaZnuLS.js";
const exposesMap = {
  "./index": async () => {
    const importModule = await __vitePreload(() => import("./App-YvhEHE9b.js").then((n) => n.A), true ? __vite__mapDeps([0,1,2,3,4]) : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./enUS": async () => {
    const importModule = await __vitePreload(() => import("./en-US-paiRZuNY.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./zhCN": async () => {
    const importModule = await __vitePreload(() => import("./zh-CN-CSSxOfdP.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  }
};
export {
  exposesMap as default
};
