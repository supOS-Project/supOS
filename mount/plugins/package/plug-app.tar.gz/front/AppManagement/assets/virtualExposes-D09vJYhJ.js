const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/App-J0aau4g8.js","assets/supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__-CIkKOcLY.js","assets/_commonjsHelpers-DWwsNxpa.js","assets/supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__-CApMxZ07.js","assets/App-DT6AJ9cx.css"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-DKVWPV7k.js";
const exposesMap = {
  "./index": async () => {
    const importModule = await __vitePreload(() => import("./App-J0aau4g8.js").then((n) => n.A), true ? __vite__mapDeps([0,1,2,3,4]) : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./enUS": async () => {
    const importModule = await __vitePreload(() => import("./en-US-Dpr-TIdl.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./zhCN": async () => {
    const importModule = await __vitePreload(() => import("./zh-CN-BN2kBRTM.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./detail": async () => {
    const importModule = await __vitePreload(() => import("./detail-BOG_8PV-.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  }
};
export {
  exposesMap as default
};
