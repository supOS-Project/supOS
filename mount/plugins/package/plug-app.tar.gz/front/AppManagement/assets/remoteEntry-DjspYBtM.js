const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-B0OThK7f.js","assets/_commonjsHelpers-DWwsNxpa.js","assets/index-CzFzz5U7.js","assets/supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__-CIkKOcLY.js","assets/supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__-CApMxZ07.js","assets/supos_mf_2_ce_mf_1_AppManagement__loadShare__react_mf_2_dom__loadShare__-DZayG9TT.js","assets/index-CaN-fJSP.js","assets/index-DZq7ITX5.js","assets/DownloadOutlined-D0QwgHBG.js","assets/dayjs.min-D_VCEmOx.js","assets/index-XCUDoEvy.js","assets/index-B0vbuXQ3.js","assets/index-Cwc3LIcg.js"])))=>i.map(i=>d[i]);
import { i as index_cjs, s as supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__-CApMxZ07.js";
import exposesMap from "./virtualExposes-D09vJYhJ.js";
import { _ as __vitePreload } from "./preload-helper-DKVWPV7k.js";
const importMap = {
  "react": async () => {
    let pkg = await __vitePreload(() => import("./index-B0OThK7f.js").then((n) => n.i), true ? __vite__mapDeps([0,1]) : void 0);
    return pkg;
  },
  "react-router-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-CzFzz5U7.js"), true ? __vite__mapDeps([2,3,1,4,5]) : void 0);
    return pkg;
  },
  "@carbon/icons-react": async () => {
    let pkg = await __vitePreload(() => import("./index-CaN-fJSP.js"), true ? __vite__mapDeps([6,1,3,4]) : void 0);
    return pkg;
  },
  "antd": async () => {
    let pkg = await __vitePreload(() => import("./index-DZq7ITX5.js"), true ? __vite__mapDeps([7,3,1,4,8,5,9]) : void 0);
    return pkg;
  },
  "ahooks": async () => {
    let pkg = await __vitePreload(() => import("./index-XCUDoEvy.js"), true ? __vite__mapDeps([10,3,1,4,9]) : void 0);
    return pkg;
  },
  "react-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-B0vbuXQ3.js").then((n) => n.i), true ? __vite__mapDeps([11,1,3,4]) : void 0);
    return pkg;
  },
  "@ant-design/icons": async () => {
    let pkg = await __vitePreload(() => import("./index-Cwc3LIcg.js"), true ? __vite__mapDeps([12,3,1,4,8]) : void 0);
    return pkg;
  }
};
const usedShared = {
  "react": {
    name: "react",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["react"].loaded = true;
      const { "react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "react-router-dom": {
    name: "react-router-dom",
    version: "6.28.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["react-router-dom"].loaded = true;
      const { "react-router-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^6.27.0"
    }
  },
  "@carbon/icons-react": {
    name: "@carbon/icons-react",
    version: "11.60.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["@carbon/icons-react"].loaded = true;
      const { "@carbon/icons-react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^11.60.0"
    }
  },
  "antd": {
    name: "antd",
    version: "5.25.2",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["antd"].loaded = true;
      const { "antd": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^5.25.2"
    }
  },
  "ahooks": {
    name: "ahooks",
    version: "3.8.5",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["ahooks"].loaded = true;
      const { "ahooks": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^3.8.5"
    }
  },
  "react-dom": {
    name: "react-dom",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["react-dom"].loaded = true;
      const { "react-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "@ant-design/icons": {
    name: "@ant-design/icons",
    version: "5.5.2",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/AppManagement",
    async get() {
      usedShared["@ant-design/icons"].loaded = true;
      const { "@ant-design/icons": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^5.5.2"
    }
  }
};
const usedRemotes = [
  {
    entryGlobalName: "supos-ce/host",
    name: "@supos_host",
    type: "var",
    entry: "/mf-manifest.json",
    shareScope: "default"
  }
];
const initTokens = {};
const shareScopeName = "default";
const mfName = "supos-ce/AppManagement";
async function init(shared = {}, initScope = []) {
  const initRes = index_cjs.init({
    name: mfName,
    remotes: usedRemotes,
    shared: usedShared,
    plugins: [],
    shareStrategy: "version-first"
  });
  var initToken = initTokens[shareScopeName];
  if (!initToken)
    initToken = initTokens[shareScopeName] = { from: mfName };
  if (initScope.indexOf(initToken) >= 0) return;
  initScope.push(initToken);
  initRes.initShareScopeMap("default", shared);
  try {
    await Promise.all(await initRes.initializeSharing("default", {
      strategy: "version-first",
      from: "build",
      initScope
    }));
  } catch (e) {
    console.error(e);
  }
  supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__.initResolve(initRes);
  return initRes;
}
function getExposes(moduleName) {
  if (!(moduleName in exposesMap)) throw new Error(`Module ${moduleName} does not exist in container.`);
  return exposesMap[moduleName]().then((res) => () => res);
}
export {
  getExposes as get,
  init
};
