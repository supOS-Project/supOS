import { s as supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__-CIkKOcLY.js";
import { s as supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__-CApMxZ07.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$2 } = index_cjs;
const { initPromise: initPromise$6 } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res$6 = initPromise$6.then((_) => loadShare$2("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$6 = await res$6.then((factory) => factory());
var supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$6;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadRemote$3("@supos_host/hooks"));
const exportModule$5 = await initPromise$5.then((_) => res$5);
var supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$5;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadRemote$2("@supos_host/utils"));
const exportModule$4 = await initPromise$4.then((_) => res$4);
var supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule$4;
const baseUrl = "/inter-api/supos/third-apps";
const api = new supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const pageListApi = async (data) => api.post("/pageList", data, {
  [supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.CustomAxiosConfigEnum.BusinessResponse]: true
});
const uninstallAppApi = async (data) => api.post("/uninstallApp", void 0, { params: data });
const stopAppApi = async (data) => api.post("/stopApp", void 0, { params: data });
const startAppApi = async (data) => api.post("/startApp", void 0, { params: data });
const installAppApi = async (data) => api.post("/install", void 0, { params: data });
const updateConfigApi = async (data) => api.put("/properties", data);
const refreshAppStatus = async (id) => api.get(`/refresh?appId=${id}`);
const uploadApp = async (data) => api.uploads("/upload", data, { method: "post", [supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.CustomAxiosConfigEnum.BusinessResponse]: true });
const deleteApp = async (params) => api.delete("/deleteApp", { params });
const batchStartApp = async (params) => api.post("/batchStartApp", params);
const batchStopApp = async (params) => api.post("/batchStopApp", params);
const existApp = async (appId) => api.get(`/existApp?appId=${appId}`);
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadShare$1("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.25.2"
  } }
}));
const exportModule$3 = await res$3.then((factory) => factory());
var supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__ = exportModule$3;
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadRemote$1("@supos_host/components"));
const exportModule$2 = await initPromise$2.then((_) => res$2);
var supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$2;
const REMOTE_NAME = "AppManagement";
const usePropertiesModal = ({ successBackFn }) => {
  const formatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const [open, setOpen] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState(false);
  const [loading, setLoading] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState(false);
  const { message } = supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.App.useApp();
  const infoRef = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useRef();
  const [value, setValue] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState("");
  const setModalOpen = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useCallback(
    (info) => {
      setOpen(true);
      setValue(info == null ? void 0 : info.appProperties);
      infoRef.current = info;
    },
    [setOpen]
  );
  const onClose = () => {
    setOpen(false);
    setLoading(false);
  };
  const onSave = () => {
    var _a;
    updateConfigApi({
      appId: (_a = infoRef.current) == null ? void 0 : _a.appId,
      properties: value
    }).then(() => {
      onClose();
      successBackFn == null ? void 0 : successBackFn();
      message.success(formatMessage("updateConfigSuccess"));
    });
  };
  const Dom = /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProModal, { className: "labelModalWrap", open, onCancel: onClose, title: formatMessage("updateConfig"), size: "sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Input.TextArea,
      {
        value,
        onChange: (e) => setValue(e.target.value),
        placeholder: commonFormatMessage("common.commonPlaceholder"),
        rows: 15,
        allowClear: true,
        style: { marginBottom: 20 }
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { gap: "10px", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Button,
        {
          loading,
          style: {
            backgroundColor: "var(--supos-button-def-10)",
            color: "var(--supos-text-color)"
          },
          color: "default",
          variant: "filled",
          block: true,
          onClick: onClose,
          children: commonFormatMessage("common.cancel")
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Button, { loading, type: "primary", variant: "solid", onClick: onSave, block: true, children: commonFormatMessage("common.save") })
    ] })
  ] });
  return {
    PropertiesModal: Dom,
    setPropertiesOpen: setModalOpen
  };
};
const { loadRemote } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote("@supos_host/button-permission"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__ = exportModule$1;
const flex = "_flex_vzyw0_1";
const styles = {
  "app-management": "_app-management_vzyw0_1",
  flex
};
const defaultIconUrl = "data:image/svg+xml,%3csvg%20width='29'%20height='29'%20viewBox='0%200%2029%2029'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3crect%20width='28'%20height='28'%20transform='translate(0.691406%200.5)'%20fill='white'%20fill-opacity='0.01'%20style='mix-blend-mode:multiply'/%3e%3cpath%20d='M23.2839%209.25H26.9414V7.5H23.2839C23.1%206.99324%2022.7645%206.5554%2022.323%206.24599C21.8815%205.93657%2021.3555%205.77058%2020.8164%205.77058C20.2773%205.77058%2019.7513%205.93657%2019.3098%206.24599C18.8683%206.5554%2018.5328%206.99324%2018.3489%207.5H12.0664V4.875H5.06641V7.5H2.44141V9.25H5.06641V11.875H12.0664V9.25H18.3489C18.4796%209.61697%2018.6902%209.95027%2018.9657%2010.2257C19.2411%2010.5012%2019.5744%2010.7118%2019.9414%2010.8425V17.2475C19.3395%2017.4046%2018.7904%2017.7193%2018.3506%2018.1591C17.9107%2018.599%2017.596%2019.1481%2017.4389%2019.75H2.44141V21.5H17.4389C17.6404%2022.2414%2018.0803%2022.896%2018.6907%2023.3626C19.3011%2023.8293%2020.0481%2024.0821%2020.8164%2024.0821C21.5847%2024.0821%2022.3317%2023.8293%2022.9421%2023.3626C23.5525%2022.896%2023.9924%2022.2414%2024.1939%2021.5H26.9414V19.75H24.1939C24.0368%2019.1481%2023.7221%2018.599%2023.2823%2018.1591C22.8424%2017.7193%2022.2933%2017.4046%2021.6914%2017.2475V10.8425C22.0584%2010.7118%2022.3917%2010.5012%2022.6671%2010.2257C22.9426%209.95027%2023.1533%209.61697%2023.2839%209.25ZM10.3164%2010.125H6.81641V6.625H10.3164V10.125ZM22.5664%2020.625C22.5664%2020.9711%2022.4638%2021.3095%2022.2715%2021.5972C22.0792%2021.885%2021.8059%2022.1093%2021.4861%2022.2418C21.1663%2022.3742%2020.8145%2022.4089%2020.475%2022.3414C20.1355%2022.2738%2019.8237%2022.1072%2019.579%2021.8624C19.3342%2021.6177%2019.1676%2021.3059%2019.1%2020.9664C19.0325%2020.6269%2019.0672%2020.2751%2019.1996%2019.9553C19.3321%2019.6355%2019.5564%2019.3622%2019.8442%2019.1699C20.1319%2018.9776%2020.4703%2018.875%2020.8164%2018.875C21.2805%2018.875%2021.7257%2019.0594%2022.0538%2019.3876C22.382%2019.7158%2022.5664%2020.1609%2022.5664%2020.625Z'%20fill='%23585C62'/%3e%3c/svg%3e";
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("ahooks", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^3.8.5"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_AppManagement__loadShare__ahooks__loadShare__ = exportModule;
const { Paragraph } = supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Typography;
const preUrl = "/files/system/resource/supos";
const { Dragger } = supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Upload;
const StatusOptions = [
  {
    value: "NOT_INSTALL",
    label: "NOT_INSTALL",
    color: "#E0E0E0"
  },
  {
    value: "START_WAITING",
    label: "START_WAITING",
    color: "orange"
  },
  {
    value: "STOPPED",
    label: "STOPPED",
    color: "orange"
  },
  {
    value: "RUNNING",
    label: "RUNNING",
    color: "green"
  },
  {
    value: "INSTALL_FAIL",
    label: "INSTALL_FAIL",
    color: "red"
  },
  {
    value: "START_FAIL",
    label: "START_FAIL",
    color: "red"
  }
];
const CardSecondaryTitle = ({
  version,
  vendorName,
  dependencies
}) => {
  const commonFormatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { overflow: "hidden", margin: "4px 0" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { justify: "space-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { style: { flex: 1, overflow: "hidden" }, gap: 4, title: vendorName, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          commonFormatMessage("common.dev"),
          ":"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { flex: 1, overflow: "hidden" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Paragraph,
          {
            ellipsis: {
              rows: 1
            },
            style: { margin: 0, wordBreak: "break-all", opacity: 0.6, lineHeight: "18px" },
            children: vendorName
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { style: { flexShrink: 0 }, align: "center", gap: 4, title: version, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          commonFormatMessage("common.version"),
          ":"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: version })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { style: { flex: 1, overflow: "hidden" }, gap: 4, title: dependencies, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
        commonFormatMessage("common.dependencies"),
        ":"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { flex: 1, overflow: "hidden" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        Paragraph,
        {
          ellipsis: {
            rows: 1
          },
          style: { margin: 0, wordBreak: "break-all", opacity: 0.6, lineHeight: "18px" },
          children: dependencies
        }
      ) })
    ] })
  ] });
};
const CardTag = ({ status, doc, latestFailMsg }) => {
  const formatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const info = (StatusOptions == null ? void 0 : StatusOptions.find((f2) => f2.value === status)) ?? {
    label: status,
    color: "blue"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { align: "center", justify: "flex-end", gap: 4, children: [
    ["INSTALL_FAIL", "START_FAIL"].includes(status) && latestFailMsg && /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Popover,
      {
        content: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { maxWidth: 400, maxHeight: 400, overflow: "auto" }, children: latestFailMsg }),
        title: commonFormatMessage("common.errorInfo"),
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.InformationFilled, { color: "red" })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Tag, { bordered: false, color: info == null ? void 0 : info.color, style: { borderRadius: 9, height: 16, lineHeight: "16px" }, children: formatMessage(info == null ? void 0 : info.label) }),
    doc && /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Button,
      {
        size: "small",
        type: "text",
        onClick: () => {
          if (doc) {
            window.open(`${preUrl}${doc}`);
          }
        },
        style: { color: "var(--supos-text-color)" },
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Document, { size: 16 }),
        children: formatMessage("document")
      }
    )
  ] });
};
const CardOperation = ({ status, appId, appProperties, refreshRequest, setLoading }) => {
  const { PropertiesModal, setPropertiesOpen } = usePropertiesModal({
    successBackFn: refreshRequest
  });
  const variant = setLoading ? void 0 : "text";
  const formatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const { message: message2, modal } = supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.App.useApp();
  const onOptHandle = (apiStr) => {
    var _a;
    setLoading == null ? void 0 : setLoading(true);
    const api2 = {
      uninstallAppApi,
      installAppApi,
      stopAppApi,
      startAppApi,
      deleteApp
    };
    (_a = api2 == null ? void 0 : api2[apiStr]) == null ? void 0 : _a.call(api2, { appId }).then(() => {
      refreshRequest == null ? void 0 : refreshRequest();
      message2.success(commonFormatMessage("common.optsuccess"));
    }).finally(() => {
      setLoading == null ? void 0 : setLoading(false);
    });
  };
  const getDom = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useCallback(
    (status2) => {
      switch (status2) {
        case "NOT_INSTALL":
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.install"],
                size: "small",
                type: "primary",
                variant,
                onClick: () => onOptHandle("installAppApi"),
                children: formatMessage("install")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.updateConfig"],
                size: "small",
                style: { color: "var(--supos-theme-color)" },
                onClick: () => setPropertiesOpen({ appProperties, appId }),
                children: formatMessage("updateConfig")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                title: formatMessage("delete"),
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.TrashCan, {}),
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.delete"],
                size: "small",
                onClick: () => {
                  modal.confirm({
                    title: commonFormatMessage("common.deleteConfirm"),
                    onOk: () => {
                      onOptHandle("deleteApp");
                    },
                    cancelButtonProps: {},
                    okText: commonFormatMessage("common.confirm")
                  });
                }
              }
            )
          ] });
        case "INSTALL_FAIL":
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.install"],
                size: "small",
                type: "primary",
                onClick: () => onOptHandle("installAppApi"),
                children: formatMessage("reInstall")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.updateConfig"],
                size: "small",
                style: { color: "var(--supos-theme-color)" },
                onClick: () => setPropertiesOpen({ appProperties, appId }),
                children: formatMessage("updateConfig")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                title: formatMessage("delete"),
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.TrashCan, {}),
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.delete"],
                size: "small",
                onClick: () => {
                  modal.confirm({
                    title: commonFormatMessage("common.deleteConfirm"),
                    onOk: () => {
                      onOptHandle("deleteApp");
                    },
                    cancelButtonProps: {},
                    okText: commonFormatMessage("common.confirm")
                  });
                }
              }
            )
          ] });
        case "STOPPED":
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.start"],
                size: "small",
                color: "primary",
                variant: "outlined",
                onClick: () => onOptHandle("startAppApi"),
                children: formatMessage("start")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.updateConfig"],
                size: "small",
                style: { color: "var(--supos-theme-color)" },
                onClick: () => setPropertiesOpen({ appProperties, appId }),
                children: formatMessage("updateConfig")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.unInstall"],
                size: "small",
                style: { color: "var(--supos-text-color)" },
                onClick: () => onOptHandle("uninstallAppApi"),
                children: formatMessage("unInstall")
              }
            )
          ] });
        case "RUNNING":
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.pause"],
                size: "small",
                color: "6F6F6F",
                variant: "solid",
                style: {
                  backgroundColor: "#6F6F6F",
                  color: "white"
                },
                onClick: () => onOptHandle("stopAppApi"),
                children: formatMessage("pause")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.updateConfig"],
                size: "small",
                style: { color: "var(--supos-theme-color)" },
                onClick: () => setPropertiesOpen({ appProperties, appId }),
                children: formatMessage("updateConfig")
              }
            )
          ] });
        case "START_FAIL":
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.start"],
                size: "small",
                color: "primary",
                variant: "outlined",
                onClick: () => onOptHandle("startAppApi"),
                children: formatMessage("start")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.updateConfig"],
                size: "small",
                style: { color: "var(--supos-theme-color)" },
                onClick: () => setPropertiesOpen({ appProperties, appId }),
                children: formatMessage("updateConfig")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
              {
                auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.unInstall"],
                size: "small",
                style: { color: "var(--supos-text-color)" },
                onClick: () => onOptHandle("uninstallAppApi"),
                children: formatMessage("unInstall")
              }
            )
          ] });
        default:
          return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.InlineLoading, { status: "active", description: formatMessage(status2) });
      }
    },
    [status, appId, appProperties]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Space, { children: [
      getDom(status),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Button, { size: "small", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Renew,
        {
          style: { cursor: "pointer" },
          onClick: () => {
            setLoading == null ? void 0 : setLoading(true);
            refreshAppStatus(appId).then(() => {
              message2.success(commonFormatMessage("common.refreshSuccessful"));
            }).finally(() => {
              setLoading == null ? void 0 : setLoading(false);
            });
          }
        }
      ) })
    ] }),
    PropertiesModal
  ] });
};
const LoadingOperation = ({ d, refreshRequest }) => {
  const [loading, setLoading] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState(false);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Spin, { spinning: loading, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    CardOperation,
    {
      status: d.status,
      appId: d.appId,
      appProperties: d.appProperties,
      refreshRequest,
      setLoading
    }
  ) });
};
const LoadingCard = ({ d, refreshRequest }) => {
  const [loading, setLoading] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState(false);
  const commonFormatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const formatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const info = appHealthStatusObj == null ? void 0 : appHealthStatusObj[d == null ? void 0 : d.appHealthStatus];
  const statusInfo = {
    label: commonFormatMessage(`common.${info == null ? void 0 : info.key}`),
    title: formatMessage(`healthStates`),
    color: info == null ? void 0 : info.color
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComCard,
    {
      checkValue: d.id,
      statusColor: info == null ? void 0 : info.color,
      statusInfo,
      updateTime: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(d == null ? void 0 : d.lastInstallTime),
      style: { width: 320, height: 290 },
      title: d.appShowName,
      secondaryTitle: /* @__PURE__ */ jsxRuntimeExports.jsx(CardSecondaryTitle, { dependencies: d.dependencies, version: d.version, vendorName: d.vendorName }),
      description: d.description || " ",
      tag: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { align: "center", style: { marginBottom: 6, marginTop: 2 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTag, { status: d.status, doc: d.doc, latestFailMsg: d.latestFailMsg }) }),
      imageSrc: `${preUrl}${d.icon}`,
      loading,
      operation: /* @__PURE__ */ jsxRuntimeExports.jsx(
        CardOperation,
        {
          status: d.status,
          appId: d.appId,
          appProperties: d.appProperties,
          refreshRequest,
          setLoading
        }
      )
    },
    d.id
  );
};
const appHealthStatusObj = {
  gray: {
    color: "#C6C6C6",
    key: "unRun"
  },
  yellow: {
    color: "#F1C21B",
    key: "partRun"
  },
  green: {
    color: "#6FDC8C",
    key: "run"
  }
};
const Index = ({ title }) => {
  const commonFormatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const formatMessage = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [open, setOpen] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState(false);
  const [mode, setMode] = supos_mf_2_ce_mf_1_AppManagement__loadShare__ahooks__loadShare__.useLocalStorageState("SUPOS_APP_MODE", {
    defaultValue: "card"
  });
  const [buttonLoading, setButtonLoading] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState(false);
  const [fileList, setFileList] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState([]);
  const { isH5 } = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useMediaSize();
  const [uploadTitle, setUploadTitle] = supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.useState("save");
  const showTotal = (total) => isH5 ? null : `${commonFormatMessage("common.total")}  ${total}  ${commonFormatMessage("common.items")}`;
  const { loading, pagination, data, refreshRequest, rowSelection, selectedRows, setLoading } = supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.usePagination({
    fetchApi: pageListApi,
    autoRefresh: true,
    initPageSize: 18
  });
  const onClose = () => {
    setFileList([]);
    setOpen(false);
    setUploadTitle("save");
    setButtonLoading(false);
  };
  const onSave = () => {
    if (fileList.length) {
      setButtonLoading(true);
      setUploadTitle("uploading");
      const item = fileList[0];
      uploadApp([{ value: item, name: "file", fileName: item.name }]).then((res2) => {
        setUploadTitle("unZiping");
        const fn = () => {
          var _a;
          (_a = existApp(res2 == null ? void 0 : res2.data)) == null ? void 0 : _a.then((data2) => {
            if (data2) {
              refreshRequest == null ? void 0 : refreshRequest();
              onClose();
              supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.message.success(commonFormatMessage("common.optsuccess"));
              setButtonLoading(false);
              setUploadTitle("save");
            } else {
              setTimeout(() => {
                fn();
              }, 2e3);
            }
          }).catch(() => {
            setButtonLoading(false);
            setUploadTitle("save");
          });
        };
        setTimeout(() => {
          fn();
        }, 2e3);
      }).catch(() => {
        setButtonLoading(false);
        setUploadTitle("save");
      });
    } else {
      supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.message.warning(commonFormatMessage("uns.pleaseUploadTheFile"));
    }
  };
  const beforeUpload = (file) => {
    const fileType = file.name.split(".").pop();
    if (["zip"].includes(fileType.toLowerCase())) {
      setFileList([file]);
    } else {
      supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.message.warning(commonFormatMessage("common.theFileFormatType", { fileType: ".zip" }));
    }
    return false;
  };
  const columns = [
    {
      dataIndex: "appShowName",
      ellipsis: true,
      fixed: "left",
      title: formatMessage("appName"),
      width: "10%",
      render: (text, record) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Image,
            {
              wrapperStyle: { marginRight: 8 },
              preview: false,
              src: `${preUrl}${record.icon}`,
              width: 20,
              height: 20,
              fallback: defaultIconUrl
            }
          ),
          text
        ] });
      }
    },
    {
      dataIndex: "vendorName",
      ellipsis: true,
      title: commonFormatMessage("common.dev"),
      width: "10%"
    },
    {
      dataIndex: "version",
      ellipsis: true,
      title: commonFormatMessage("common.version"),
      width: "10%"
    },
    {
      dataIndex: "dependencies",
      ellipsis: true,
      title: commonFormatMessage("common.dependencies"),
      width: "10%"
    },
    {
      dataIndex: "lastInstallTime",
      ellipsis: true,
      title: formatMessage("installationTime"),
      width: "10%",
      render: (t) => {
        return supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(t);
      }
    },
    {
      dataIndex: "status",
      ellipsis: true,
      title: commonFormatMessage("common.states"),
      width: "10%",
      render: (status, record) => {
        const info = (StatusOptions == null ? void 0 : StatusOptions.find((f2) => f2.value === status)) ?? {
          label: status,
          color: "blue"
        };
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 4, children: [
          ["INSTALL_FAIL", "START_FAIL"].includes(status) && (record == null ? void 0 : record.latestFailMsg) && /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Popover,
            {
              content: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { maxWidth: 400, maxHeight: 400, overflow: "auto" }, children: record == null ? void 0 : record.latestFailMsg }),
              title: commonFormatMessage("common.errorInfo"),
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.InformationFilled, { color: "red" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Tag, { bordered: false, color: info == null ? void 0 : info.color, style: { borderRadius: 9, height: 16, lineHeight: "16px" }, children: formatMessage(info == null ? void 0 : info.label) }),
          (record == null ? void 0 : record.doc) && /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Button,
            {
              size: "small",
              type: "text",
              onClick: () => {
                if (record == null ? void 0 : record.doc) {
                  window.open(`${preUrl}${record == null ? void 0 : record.doc}`);
                }
              },
              style: { color: "var(--supos-text-color)" },
              icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Document, { size: 16 }),
              children: formatMessage("document")
            }
          )
        ] });
      }
    },
    {
      dataIndex: "appHealthStatus",
      title: formatMessage("healthStates"),
      width: "5%",
      render: (text) => {
        const info = appHealthStatusObj[text];
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { justify: "flex-start", align: "center", gap: 4, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { width: 5, height: 5, borderRadius: "50%", background: info == null ? void 0 : info.color } }),
          commonFormatMessage(`common.${info == null ? void 0 : info.key}`)
        ] });
      }
    },
    // {
    //   dataIndex: 'config',
    //   ellipsis: true,
    //   title: commonFormatMessage('common.config'),
    //   width: '10%',
    // },
    {
      dataIndex: "operation",
      ellipsis: true,
      fixed: "right",
      title: commonFormatMessage("common.operation"),
      width: "15%",
      render: (_, record) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingOperation, { d: record, refreshRequest });
      }
    }
  ];
  const onBatchHandle = (str) => {
    var _a;
    setLoading(true);
    const api2 = {
      batchStopApp,
      batchStartApp
    };
    (_a = api2 == null ? void 0 : api2[str]) == null ? void 0 : _a.call(api2, {
      appIdList: selectedRows == null ? void 0 : selectedRows.map((m2) => m2.appId)
    }).then((data2) => {
      console.log(data2);
      supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.message.success(data2);
      refreshRequest == null ? void 0 : refreshRequest(void 0, { clearSelect: true });
    }).finally(() => {
      setLoading(false);
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
      {
        title: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
            },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Apps, { size: 20, style: { justifyContent: "center", verticalAlign: "middle" } }),
              " ",
              title
            ]
          }
        ),
        hasBack: false,
        style: {
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          height: "100%"
        },
        extra: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Space, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.start"],
              style: { height: 28 },
              color: "primary",
              variant: "outlined",
              disabled: !(selectedRows == null ? void 0 : selectedRows.length),
              onClick: () => {
                onBatchHandle("batchStartApp");
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 6, children: formatMessage("batchStart") })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.pause"],
              style: { height: 28 },
              color: "primary",
              variant: "outlined",
              disabled: !(selectedRows == null ? void 0 : selectedRows.length),
              onClick: () => {
                onBatchHandle("batchStopApp");
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 6, children: formatMessage("batchPause") })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["appManagement.upload"],
              style: { height: 28 },
              onClick: () => {
                setOpen(true);
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 6, children: commonFormatMessage("common.uploadApp") })
            }
          )
        ] }),
        className: styles["app-management"],
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { justify: "flex-end", align: "center", style: { marginTop: 16, paddingRight: 16 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Segmented,
            {
              size: "small",
              value: mode,
              onChange: (v) => setMode(v),
              options: [
                {
                  value: "card",
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles["flex"], title: commonFormatMessage("common.cardMode"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Grid, {}) })
                },
                {
                  value: "list",
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles["flex"], title: commonFormatMessage("common.listMode"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.List, {}) })
                }
              ]
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { flex: 1, padding: 16, overflow: "auto" }, children: mode === "card" ? (data == null ? void 0 : data.length) > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Checkbox.Group,
            {
              value: rowSelection.selectedRowKeys,
              onChange: (checkedValues) => {
                rowSelection.onChange(checkedValues);
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { gap: 18, wrap: true, align: "flex-start", justify: "flex-start", children: data == null ? void 0 : data.map((d) => {
                return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingCard, { d, refreshRequest }, d.id);
              }) })
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { style: { width: "100%" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Empty, { style: { width: "100%" } }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProTable,
            {
              resizeable: true,
              style: { height: "100%" },
              scroll: { y: "calc(100vh  - 285px)", x: "max-content" },
              dataSource: data,
              columns,
              pagination: {
                total: pagination == null ? void 0 : pagination.total,
                showTotal,
                style: { display: "flex", justifyContent: "flex-end", padding: "10px 0" },
                pageSize: (pagination == null ? void 0 : pagination.pageSize) || 20,
                current: pagination == null ? void 0 : pagination.page,
                showQuickJumper: true,
                pageSizeOptions: pagination == null ? void 0 : pagination.pageSizes,
                onChange: pagination.onChange,
                onShowSizeChange: (current, size) => {
                  pagination.onChange({ page: current, pageSize: size });
                }
              },
              rowSelection
            }
          ) }),
          mode === "card" && /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Pagination,
            {
              size: "small",
              className: "custom-pagination",
              align: "center",
              style: { margin: "20px 0" },
              total: pagination == null ? void 0 : pagination.total,
              showSizeChanger: false,
              onChange: pagination.onChange,
              pageSize: (pagination == null ? void 0 : pagination.pageSize) || 20,
              current: pagination == null ? void 0 : pagination.page
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      supos_mf_2_ce_mf_1_AppManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProModal,
      {
        "aria-label": "",
        title: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { display: "flex", justifyContent: "space-between" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: commonFormatMessage("common.uploadApp") }) }),
        onCancel: onClose,
        open,
        className: "importModalWrap",
        size: "xxs",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Dragger,
            {
              className: "uploadWrap",
              action: "",
              accept: ".zip",
              maxCount: 1,
              fileList,
              disabled: buttonLoading,
              beforeUpload,
              onRemove: () => {
                setFileList([]);
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Flex, { vertical: true, align: "center", gap: 10, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.FolderAdd, { size: 100, style: { color: "#E0E0E0" } }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { fontSize: 12 }, children: commonFormatMessage("common.theFileFormatType", { fileType: ".zip" }) })
              ] })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_AppManagement__loadShare__antd__loadShare__.Button,
            {
              loading: buttonLoading,
              color: "primary",
              variant: "solid",
              block: true,
              onClick: onSave,
              style: { marginTop: 20 },
              children: commonFormatMessage(`common.${uploadTitle}`)
            }
          )
        ]
      }
    )
  ] });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Index
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  Index as I,
  jsxRuntimeExports as j
};
