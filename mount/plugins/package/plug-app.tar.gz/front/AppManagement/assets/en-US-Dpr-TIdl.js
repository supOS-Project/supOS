const detailPageName = "App-detail";
const document = "Document";
const NOT_INSTALL = "Uninstalled";
const STOPPING = "Stopping";
const STARTING = "Starting";
const UNINSTALLING = "UnInstalling";
const INSTALLING = "Installation";
const INSTALL_FAIL = "Installation Failed";
const RUNNING = "Running";
const START_WAITING = "Not started";
const STOPPED = "Not started";
const updateConfig = "Update Config";
const install = "Install";
const reInstall = "Reinstall";
const unInstall = "Uninstall";
const start = "Start";
const batchStart = "Batch Start";
const batchPause = "Batch Pause";
const pause = "Pause";
const START_FAIL = "Failed Start";
const updateConfigSuccess = "Configuration modification successfully, please restart the ";
const appName = "Application name";
const installationTime = "Installation time";
const healthStates = "Health status";
const enUS = {
  detailPageName,
  document,
  NOT_INSTALL,
  STOPPING,
  STARTING,
  UNINSTALLING,
  INSTALLING,
  INSTALL_FAIL,
  RUNNING,
  START_WAITING,
  STOPPED,
  updateConfig,
  install,
  reInstall,
  unInstall,
  "delete": "Delete",
  start,
  batchStart,
  batchPause,
  pause,
  START_FAIL,
  updateConfigSuccess,
  appName,
  installationTime,
  healthStates
};
export {
  INSTALLING,
  INSTALL_FAIL,
  NOT_INSTALL,
  RUNNING,
  STARTING,
  START_FAIL,
  START_WAITING,
  STOPPED,
  STOPPING,
  UNINSTALLING,
  appName,
  batchPause,
  batchStart,
  enUS as default,
  detailPageName,
  document,
  healthStates,
  install,
  installationTime,
  pause,
  reInstall,
  start,
  unInstall,
  updateConfig,
  updateConfigSuccess
};
