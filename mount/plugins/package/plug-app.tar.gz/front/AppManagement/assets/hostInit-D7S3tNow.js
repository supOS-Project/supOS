const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/remoteEntry-DjspYBtM.js","assets/supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__-CApMxZ07.js","assets/virtualExposes-D09vJYhJ.js","assets/preload-helper-DKVWPV7k.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-DKVWPV7k.js";
const remoteEntryPromise = __vitePreload(() => import("./remoteEntry-DjspYBtM.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
Promise.resolve(remoteEntryPromise).then((remoteEntry) => {
  return Promise.resolve(remoteEntry.__tla).then(remoteEntry.init).catch(remoteEntry.init);
});
