const Detail = () => {
  return "详情页";
};
export {
  Detail as default
};
