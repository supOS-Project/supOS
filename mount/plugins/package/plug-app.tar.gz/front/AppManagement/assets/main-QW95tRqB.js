import "./hostInit-D7S3tNow.js";
import { i as index_cjs, s as supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__-CApMxZ07.js";
import { j as jsxRuntimeExports, I as Index } from "./App-J0aau4g8.js";
import { s as supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__-CIkKOcLY.js";
import { s as supos_mf_2_ce_mf_1_AppManagement__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_AppManagement__loadShare__react_mf_2_dom__loadShare__-DZayG9TT.js";
import "./preload-helper-DKVWPV7k.js";
import "./_commonjsHelpers-DWwsNxpa.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_AppManagement__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_AppManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_AppManagement__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule;
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_AppManagement__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Index, {}) }) })
);
