const detailPageName = "App管理详情页";
const document = "文档";
const NOT_INSTALL = "未安装";
const STOPPING = "停止中";
const STARTING = "启动中";
const UNINSTALLING = "卸载中";
const INSTALLING = "安装中";
const INSTALL_FAIL = "安装失败";
const RUNNING = "已启动";
const START_WAITING = "未启动";
const STOPPED = "未启动";
const updateConfig = "更新配置";
const install = "安装";
const reInstall = "重新安装";
const unInstall = "卸载";
const start = "启动";
const batchStart = "批量启动";
const batchPause = "批量暂停";
const pause = "暂停";
const START_FAIL = "启动失败";
const updateConfigSuccess = "配置修改成功，请重启App";
const appName = "App名称";
const installationTime = "安装时间";
const healthStates = "健康状态";
const zhCN = {
  detailPageName,
  document,
  NOT_INSTALL,
  STOPPING,
  STARTING,
  UNINSTALLING,
  INSTALLING,
  INSTALL_FAIL,
  RUNNING,
  START_WAITING,
  STOPPED,
  updateConfig,
  install,
  reInstall,
  unInstall,
  "delete": "删除",
  start,
  batchStart,
  batchPause,
  pause,
  START_FAIL,
  updateConfigSuccess,
  appName,
  installationTime,
  healthStates
};
export {
  INSTALLING,
  INSTALL_FAIL,
  NOT_INSTALL,
  RUNNING,
  STARTING,
  START_FAIL,
  START_WAITING,
  STOPPED,
  STOPPING,
  UNINSTALLING,
  appName,
  batchPause,
  batchStart,
  zhCN as default,
  detailPageName,
  document,
  healthStates,
  install,
  installationTime,
  pause,
  reInstall,
  start,
  unInstall,
  updateConfig,
  updateConfigSuccess
};
