import { s as supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__-Dhyw5Kbp.js";
import { s as supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__-CAwvht39.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadShare$1("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$5 = await res$5.then((factory) => factory());
var supos_mf_2_ce_mf_1_ThemeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$5;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadRemote$3("@supos_host/components"));
const exportModule$4 = await initPromise$4.then((_) => res$4);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$4;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadRemote$2("@supos_host/hooks"));
const exportModule$3 = await initPromise$3.then((_) => res$3);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$3;
const { loadShare } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadShare("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.25.2"
  } }
}));
const exportModule$2 = await res$2.then((factory) => factory());
var supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__ = exportModule$2;
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote$1("@supos_host/baseStore"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__ = exportModule$1;
const REMOTE_NAME = "ThemeManagement";
const Module$2 = ({ fileList: _fileList, fileChange, ...restProps }) => {
  const { message } = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.App.useApp();
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [fileList, setFileList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState(_fileList);
  const uploadRef = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useRef();
  const beforeUpload = (file) => {
    const fileType = file.name.split(".").pop();
    if (["jpg", "jpeg", "png", "svg"].includes(fileType.toLowerCase())) {
      const previewUrl = URL.createObjectURL(file);
      const newFile = {
        ...file,
        file,
        url: previewUrl,
        thumbUrl: previewUrl,
        status: "done"
      };
      setFileList([newFile]);
      fileChange == null ? void 0 : fileChange([newFile]);
    } else {
      message.warning(formatMessage("imgFormatSupport", { format: "jpg、jpeg、png、svg" }));
      return supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Upload.LIST_IGNORE;
    }
    return false;
  };
  const onRemove = () => {
    setFileList([]);
    fileChange == null ? void 0 : fileChange();
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    setFileList(_fileList);
  }, [_fileList]);
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    const uploadBtn = uploadRef.current.nativeElement.querySelector(".ant-upload-select");
    if (!uploadBtn) return;
    if (fileList == null ? void 0 : fileList.length) {
      uploadBtn.style.display = "none";
    } else {
      uploadBtn.style.display = "block";
    }
  }, [fileList, uploadRef]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Upload,
    {
      action: "",
      listType: "picture-card",
      maxCount: 1,
      ...restProps,
      fileList,
      accept: ".jpg,.jpeg,.png,.svg",
      beforeUpload,
      onRemove,
      ref: uploadRef,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { style: { color: "inherit", cursor: "inherit", border: 0, background: "none" }, type: "button", children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.AddLarge, {}) })
    }
  );
};
const { loadRemote } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadRemote("@supos_host/utils"));
const exportModule = await initPromise.then((_) => res);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule;
const baseUrl = "/inter-api/supos/theme";
const api = new supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const generalConfigSave = async (params) => api.uploads("/general-config/save", params, { method: "post" });
const loginConfigSave = async (params) => api.uploads("/login-page-config/save", params, { method: "post" });
const resetAllThemeConfig = async (type) => api.post(`/config/reset?type=${type}`);
const getAllThemeConfig = async (params) => api.get("/getConfig", { params });
const commonConfigForm = "_commonConfigForm_1uhv8_1";
const title$2 = "_title_1uhv8_4";
const imageSize = "_imageSize_1uhv8_8";
const styles$2 = {
  commonConfigForm,
  title: title$2,
  imageSize
};
const DEFAULT_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/logo-D-BhgvYM.svg", import.meta.url).href;
const iconDefaultList = [
  {
    uid: "-1",
    name: "logo.svg",
    url: DEFAULT_IMAGE_PATH
  }
];
const Module$1 = ({ themeConfig }) => {
  const [form] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.useForm();
  const { message } = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.App.useApp();
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const { appTitle } = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__.useBaseStore((state) => state.systemInfo);
  const [defaultBrowserTitle, setDefaultBrowserTitle] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [browserIconList, setBrowserIconList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [navLogoList, setNavLogoList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const rebuildList = (path) => {
    const timestamp = (/* @__PURE__ */ new Date()).getTime();
    return path ? [
      {
        uid: "-1",
        name: "img.png",
        url: `${location.origin}${path}?t=${timestamp}`
      }
    ] : void 0;
  };
  const addToFileList = (list, name, dataList, cb) => {
    var _a;
    if (list == null ? void 0 : list.length) {
      if ((_a = list[0]) == null ? void 0 : _a.file) {
        dataList == null ? void 0 : dataList.push({
          name,
          value: list[0].file,
          fileName: list[0].file.fileName
        });
      }
    } else {
      cb();
    }
  };
  const save = async () => {
    const values = await form.validateFields();
    const dataList = [
      {
        name: "browseTitle",
        value: values.browserTitle
      }
    ];
    let resetIcon = 0;
    addToFileList(browserIconList, "browseIcon", dataList, () => resetIcon += 1);
    addToFileList(navLogoList, "navigationIcon", dataList, () => resetIcon += 2);
    if (resetIcon) {
      dataList.push({
        name: "resetIcon",
        value: resetIcon
      });
    }
    const saveRes = await generalConfigSave(dataList);
    if (saveRes) {
      message.success(formatMessage("saveSuccess"));
    }
  };
  const reset = async () => {
    const res2 = await resetAllThemeConfig(0);
    if (res2) {
      message.success(formatMessage("resetSuccess"));
      form.setFieldValue("browserTitle", defaultBrowserTitle);
      setBrowserIconList(iconDefaultList);
      setNavLogoList(iconDefaultList);
    }
  };
  const getConfig = async (themeConfig2, init, title2) => {
    const { browseTitle, browseIcon, navigationIcon } = themeConfig2 || {};
    {
      form.setFieldValue("browserTitle", browseTitle || title2);
      setBrowserIconList(rebuildList(browseIcon) || iconDefaultList);
      setNavLogoList(rebuildList(navigationIcon) || iconDefaultList);
    }
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    const _browserTitle = `${appTitle} ${commonFormatMessage("common.excellence")}`;
    setDefaultBrowserTitle(_browserTitle);
    getConfig(themeConfig, true, _browserTitle);
  }, [appTitle, themeConfig]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form,
    {
      className: styles$2.commonConfigForm,
      name: "commonConfigForm",
      form,
      colon: false,
      labelCol: { span: 8 },
      wrapperCol: { span: 16 },
      labelAlign: "left",
      labelWrap: true,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", justify: "space-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$2.title, children: formatMessage("commonConfig") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Button, { type: "primary", onClick: save, children: formatMessage("save") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Button, { onClick: reset, children: formatMessage("reset") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "browserTitle", label: formatMessage("browserTitle"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Input, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "browserIcon", label: formatMessage("browserIcon"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Module$2,
            {
              maxCount: 1,
              fileList: browserIconList,
              fileChange: (file) => {
                setBrowserIconList(file);
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$2.imageSize, children: formatMessage("imageSize", { size: "32*32" }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "navigationLogo", label: formatMessage("navigationLogo"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Module$2,
            {
              maxCount: 1,
              fileList: navLogoList,
              fileChange: (file) => {
                setNavLogoList(file);
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$2.imageSize, children: formatMessage("imageSize", { size: "50*20" }) })
        ] }) })
      ]
    }
  );
};
const lightThemeImage = "data:image/svg+xml,%3csvg%20width='216'%20height='126'%20viewBox='0%200%20216%20126'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3crect%20x='1.01172'%20y='0.5'%20width='214'%20height='124.578'%20rx='2.5'%20fill='white'/%3e%3crect%20x='1.01172'%20y='0.5'%20width='214'%20height='124.578'%20rx='2.5'%20stroke='%23C6C6C6'/%3e%3crect%20x='25.5117'%20y='16'%20width='164.994'%20height='23.3945'%20fill='%23F4F4F4'/%3e%3cmask%20id='path-3-inside-1_8835_70494'%20fill='white'%3e%3cpath%20d='M25.5117%2039.3945H190.506V62.7891H25.5117V39.3945Z'/%3e%3c/mask%3e%3cpath%20d='M25.5117%2039.3945H190.506V62.7891H25.5117V39.3945Z'%20fill='white'/%3e%3cpath%20d='M190.506%2062.7891V61.7891H25.5117V62.7891V63.7891H190.506V62.7891Z'%20fill='%23C6C6C6'%20mask='url(%23path-3-inside-1_8835_70494)'/%3e%3cmask%20id='path-5-inside-2_8835_70494'%20fill='white'%3e%3cpath%20d='M25.5117%2062.7891H190.506V86.1836H25.5117V62.7891Z'/%3e%3c/mask%3e%3cpath%20d='M25.5117%2062.7891H190.506V86.1836H25.5117V62.7891Z'%20fill='white'/%3e%3cpath%20d='M190.506%2086.1836V85.1836H25.5117V86.1836V87.1836H190.506V86.1836Z'%20fill='%23C6C6C6'%20mask='url(%23path-5-inside-2_8835_70494)'/%3e%3cmask%20id='path-7-inside-3_8835_70494'%20fill='white'%3e%3cpath%20d='M25.5117%2086.1836H190.506V109.578H25.5117V86.1836Z'/%3e%3c/mask%3e%3cpath%20d='M25.5117%2086.1836H190.506V109.578H25.5117V86.1836Z'%20fill='white'/%3e%3cpath%20d='M190.506%20109.578V108.578H25.5117V109.578V110.578H190.506V109.578Z'%20fill='%23C6C6C6'%20mask='url(%23path-7-inside-3_8835_70494)'/%3e%3c/svg%3e";
const darkThemeImage = "data:image/svg+xml,%3csvg%20width='216'%20height='126'%20viewBox='0%200%20216%20126'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3crect%20x='1.01172'%20y='0.789062'%20width='214'%20height='124'%20rx='2.5'%20fill='%23161616'/%3e%3crect%20x='1.01172'%20y='0.789062'%20width='214'%20height='124'%20rx='2.5'%20stroke='%23C6C6C6'/%3e%3crect%20x='25.6367'%20y='16'%20width='164.994'%20height='23.3945'%20fill='%23393939'/%3e%3cmask%20id='path-3-inside-1_8835_70502'%20fill='white'%3e%3cpath%20d='M25.6367%2039.3945H190.631V62.7891H25.6367V39.3945Z'/%3e%3c/mask%3e%3cpath%20d='M25.6367%2039.3945H190.631V62.7891H25.6367V39.3945Z'%20fill='%23161616'/%3e%3cpath%20d='M190.631%2062.7891V61.7891H25.6367V62.7891V63.7891H190.631V62.7891Z'%20fill='%23C6C6C6'%20mask='url(%23path-3-inside-1_8835_70502)'/%3e%3cmask%20id='path-5-inside-2_8835_70502'%20fill='white'%3e%3cpath%20d='M25.6367%2062.7891H190.631V86.1836H25.6367V62.7891Z'/%3e%3c/mask%3e%3cpath%20d='M25.6367%2062.7891H190.631V86.1836H25.6367V62.7891Z'%20fill='%23161616'/%3e%3cpath%20d='M190.631%2086.1836V85.1836H25.6367V86.1836V87.1836H190.631V86.1836Z'%20fill='%23C6C6C6'%20mask='url(%23path-5-inside-2_8835_70502)'/%3e%3cmask%20id='path-7-inside-3_8835_70502'%20fill='white'%3e%3cpath%20d='M25.6367%2086.1836H190.631V109.578H25.6367V86.1836Z'/%3e%3c/mask%3e%3cpath%20d='M25.6367%2086.1836H190.631V109.578H25.6367V86.1836Z'%20fill='%23161616'/%3e%3cpath%20d='M190.631%20109.578V108.578H25.6367V109.578V110.578H190.631V109.578Z'%20fill='%23C6C6C6'%20mask='url(%23path-7-inside-3_8835_70502)'/%3e%3c/svg%3e";
const loginConfigForm = "_loginConfigForm_139wf_1";
const title$1 = "_title_139wf_4";
const themeImg = "_themeImg_139wf_8";
const selectTheme = "_selectTheme_139wf_13";
const styles$1 = {
  loginConfigForm,
  title: title$1,
  themeImg,
  selectTheme
};
const LOGO_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/logo-D-BhgvYM.svg", import.meta.url).href;
const BACKGROUND_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/login-background-BHqaOiVR.png", import.meta.url).href;
const SLOGAN_DARK_ZH_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/slogan-dark-zh-BCM5ajiF.png", import.meta.url).href;
const SLOGAN_DARK_EN_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/slogan-dark-en-DAkf-1_7.png", import.meta.url).href;
const SLOGAN_LIGHT_ZH_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/slogan-light-zh-C5knbrJ0.png", import.meta.url).href;
const SLOGAN_LIGHT_EN_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/slogan-light-en-Da9HvoBP.png", import.meta.url).href;
const logoDefaultList = [
  {
    uid: "-1",
    name: "logo.svg",
    url: LOGO_IMAGE_PATH
  }
];
const backgroundDefaultList = [
  {
    uid: "-1",
    name: "login-background.png",
    url: BACKGROUND_IMAGE_PATH
  }
];
const sloganLightZhDefaultList = [
  {
    uid: "-1",
    name: "slogan-light-zh.png",
    url: SLOGAN_LIGHT_ZH_IMAGE_PATH
  }
];
const sloganLightEnDefaultList = [
  {
    uid: "-1",
    name: "slogan-light-en.png",
    url: SLOGAN_LIGHT_EN_IMAGE_PATH
  }
];
const sloganDarkZhDefaultList = [
  {
    uid: "-1",
    name: "slogan-dark-zh.png",
    url: SLOGAN_DARK_ZH_IMAGE_PATH
  }
];
const sloganDarkEnDefaultList = [
  {
    uid: "-1",
    name: "slogan-dark-en.png",
    url: SLOGAN_DARK_EN_IMAGE_PATH
  }
];
const Module = ({ themeConfig, getConfig }) => {
  const [form] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.useForm();
  const { message } = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.App.useApp();
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const { lang } = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__.useBaseStore((state) => state.systemInfo);
  const [logoList, setLogoList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [backgroundList, setBackgroundList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [sloganList, setSloganList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [allConfig, setAllConfig] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState(themeConfig);
  const [init, setInit] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState(true);
  const theme = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.useWatch("theme", form);
  const addToFileList = (list, name, dataList, cb) => {
    var _a;
    if (list == null ? void 0 : list.length) {
      if ((_a = list[0]) == null ? void 0 : _a.file) {
        dataList == null ? void 0 : dataList.push({
          name,
          value: list[0].file,
          fileName: list[0].file.fileName
        });
      }
    } else {
      cb();
    }
  };
  const save = async () => {
    const values = await form.validateFields();
    const { theme: theme2 } = values;
    const dataList = [
      {
        name: "loginPageType",
        value: theme2
      }
    ];
    let resetIcon = 0;
    addToFileList(logoList, theme2 ? "darkLogoIcon" : "brightLogoIcon", dataList, () => {
      resetIcon += 1;
    });
    addToFileList(backgroundList, theme2 ? "darkBackgroundIcon" : "brightBackgroundIcon", dataList, () => {
      resetIcon += 2;
    });
    addToFileList(sloganList, theme2 ? "darkSloganIcon" : "brightSloganIcon", dataList, () => {
      resetIcon += 4;
    });
    if (resetIcon) {
      dataList.push({
        name: theme2 ? "resetDarkIcon" : "resetBrightIcon",
        value: resetIcon
      });
    }
    const saveRes = await loginConfigSave(dataList);
    if (saveRes) {
      message.success(formatMessage("saveSuccess"));
      getConfig();
    }
  };
  const reset = async () => {
    const res2 = await resetAllThemeConfig(1);
    if (res2) {
      message.success(formatMessage("resetSuccess"));
      form.setFieldValue("theme", 0);
      setSloganList([
        {
          uid: "-1",
          name: "slogan-light.png",
          url: lang === "zh-CN" ? SLOGAN_LIGHT_ZH_IMAGE_PATH : SLOGAN_LIGHT_EN_IMAGE_PATH
        }
      ]);
      setLogoList(logoDefaultList);
      setBackgroundList(backgroundDefaultList);
      getConfig();
    }
  };
  const rebuildList = (path) => {
    const timestamp = (/* @__PURE__ */ new Date()).getTime();
    return path ? [
      {
        uid: "-1",
        name: "img.png",
        url: `${location.origin}${path}?t=${timestamp}`
      }
    ] : void 0;
  };
  const handleConfig = async (themeConfig2, init2) => {
    const {
      loginPageType,
      brightLogoIcon,
      brightBackgroundIcon,
      brightSloganIcon,
      darkLogoIcon,
      darkBackgroundIcon,
      darkSloganIcon
    } = themeConfig2 || {};
    setAllConfig(themeConfig2);
    if (init2) {
      form.setFieldValue("theme", loginPageType);
      const logo = rebuildList(loginPageType ? darkLogoIcon : brightLogoIcon) || logoDefaultList;
      const background = rebuildList(loginPageType ? darkBackgroundIcon : brightBackgroundIcon) || backgroundDefaultList;
      setLogoList(logo);
      setBackgroundList(background);
      if (loginPageType) {
        setSloganList(
          rebuildList(darkSloganIcon) || (lang === "zh-CN" ? sloganDarkZhDefaultList : sloganDarkEnDefaultList)
        );
      } else {
        setSloganList(
          rebuildList(brightSloganIcon) || (lang === "zh-CN" ? sloganLightZhDefaultList : sloganLightEnDefaultList)
        );
      }
    }
    if (themeConfig2) setInit(false);
  };
  const handleThemeChange = (e) => {
    const { brightLogoIcon, brightBackgroundIcon, brightSloganIcon, darkLogoIcon, darkBackgroundIcon, darkSloganIcon } = allConfig;
    const loginPageType = e.target.value;
    const logo = rebuildList(loginPageType ? darkLogoIcon : brightLogoIcon) || logoDefaultList;
    const background = rebuildList(loginPageType ? darkBackgroundIcon : brightBackgroundIcon) || backgroundDefaultList;
    setLogoList(logo);
    setBackgroundList(background);
    if (loginPageType) {
      setSloganList(
        rebuildList(darkSloganIcon) || (lang === "zh-CN" ? sloganDarkZhDefaultList : sloganDarkEnDefaultList)
      );
    } else {
      setSloganList(
        rebuildList(brightSloganIcon) || (lang === "zh-CN" ? sloganLightZhDefaultList : sloganLightEnDefaultList)
      );
    }
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    handleConfig(themeConfig, init);
  }, [lang, themeConfig, init]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form,
    {
      className: styles$1.loginConfigForm,
      name: "loginConfigForm",
      form,
      colon: false,
      labelCol: { span: 8 },
      wrapperCol: { span: 16 },
      labelAlign: "left",
      labelWrap: true,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", justify: "space-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$1.title, children: formatMessage("loginConfig") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Button, { type: "primary", onClick: save, children: formatMessage("save") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Button, { onClick: reset, children: formatMessage("reset") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "theme", label: formatMessage("theme"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Radio.Group, { onChange: handleThemeChange, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { gap: 10, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { vertical: true, align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: `${styles$1.themeImg} ${theme === 0 ? styles$1.selectTheme : ""}`, src: lightThemeImage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Radio, { value: 0, children: formatMessage("lightTheme") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { vertical: true, align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: `${styles$1.themeImg} ${theme === 1 ? styles$1.selectTheme : ""}`, src: darkThemeImage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Radio, { value: 1, children: formatMessage("darkTheme") })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "logo", label: formatMessage("logo"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Module$2,
          {
            maxCount: 1,
            fileList: logoList,
            fileChange: (file) => {
              setLogoList(file);
            }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "background", label: formatMessage("background"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Module$2,
          {
            maxCount: 1,
            fileList: backgroundList,
            fileChange: (file) => {
              setBackgroundList(file);
            },
            style: { width: "450px" }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "slogan", label: formatMessage("slogan"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Module$2,
          {
            maxCount: 1,
            fileList: sloganList,
            fileChange: (file) => {
              setSloganList(file);
            }
          }
        ) })
      ]
    }
  );
};
const themeConfigWrap = "_themeConfigWrap_cewkv_1";
const titleBox = "_titleBox_cewkv_1";
const title = "_title_cewkv_1";
const styles = {
  themeConfigWrap,
  titleBox,
  title
};
const CodeManagement = () => {
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [themeConfig, setThemeConfig] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const getConfig = async () => {
    const res2 = await getAllThemeConfig();
    res2.loginPageType = res2.loginPageType || 0;
    setThemeConfig(res2);
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    getConfig();
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading: false, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
    {
      className: styles.themeConfigWrap,
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles.titleBox, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.PaintBrush, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles.title, children: formatMessage("themeConfig") })
      ] }),
      mustHasBack: false,
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "30px 0"
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Module$1, { themeConfig }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Module, { themeConfig, getConfig })
      ]
    }
  ) });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: CodeManagement
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  CodeManagement as C,
  jsxRuntimeExports as j
};
