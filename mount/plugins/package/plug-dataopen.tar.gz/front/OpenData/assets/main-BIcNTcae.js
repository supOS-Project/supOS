import "./hostInit-pwDq9oIG.js";
import { i as index_cjs, s as supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__-BHgn3Pql.js";
import { j as jsxRuntimeExports, O as OpenData } from "./App-4BLdjFlh.js";
import { s as supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__-BOZGjbOR.js";
import { s as supos_mf_2_ce_mf_1_OpenData__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_OpenData__loadShare__react_mf_2_dom__loadShare__-BYlGuN79.js";
import "./preload-helper-BQEDfpdQ.js";
import "./_commonjsHelpers-CUmg6egw.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_OpenData__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_OpenData__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule;
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(OpenData, {}) }) })
);
