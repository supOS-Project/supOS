const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/App-4BLdjFlh.js","assets/supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__-BOZGjbOR.js","assets/_commonjsHelpers-CUmg6egw.js","assets/supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__-BHgn3Pql.js","assets/App-DnzRqB3Q.css"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-BQEDfpdQ.js";
const exposesMap = {
  "./index": async () => {
    const importModule = await __vitePreload(() => import("./App-4BLdjFlh.js").then((n) => n.A), true ? __vite__mapDeps([0,1,2,3,4]) : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./enUS": async () => {
    const importModule = await __vitePreload(() => import("./en-US-_ZkO-14A.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./zhCN": async () => {
    const importModule = await __vitePreload(() => import("./zh-CN-CjbU01jD.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  }
};
export {
  exposesMap as default
};
