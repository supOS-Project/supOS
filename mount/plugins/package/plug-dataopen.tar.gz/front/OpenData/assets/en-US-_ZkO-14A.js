const appSceretKey = "App Key";
const creationTime = "Creation Time";
const status = "Status";
const start = "Enable";
const disable = "Disable";
const operation = "Operation";
const builtIn = "Built-in";
const newSuccessfullyAdded = "Success!";
const disabledSuccessfully = "Disabled successfully";
const startSuccessfully = "Enabled successfully";
const deleteConfirm = "Delete?";
const deleteSuccessfully = "Deleted successfully";
const openData = "Open Data";
const newKey = "New Key";
const apiList = "API List";
const enUS = {
  appSceretKey,
  creationTime,
  status,
  start,
  disable,
  operation,
  "delete": "Delete",
  builtIn,
  newSuccessfullyAdded,
  disabledSuccessfully,
  startSuccessfully,
  deleteConfirm,
  deleteSuccessfully,
  openData,
  newKey,
  apiList
};
export {
  apiList,
  appSceretKey,
  builtIn,
  creationTime,
  enUS as default,
  deleteConfirm,
  deleteSuccessfully,
  disable,
  disabledSuccessfully,
  newKey,
  newSuccessfullyAdded,
  openData,
  operation,
  start,
  startSuccessfully,
  status
};
