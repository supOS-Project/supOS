const appSceretKey = "密钥";
const creationTime = "创建时间";
const status = "状态";
const start = "启用";
const disable = "禁用";
const operation = "操作";
const builtIn = "内置";
const newSuccessfullyAdded = "新增成功";
const disabledSuccessfully = "禁用成功";
const startSuccessfully = "启用成功";
const deleteConfirm = "您确认要删除吗？";
const deleteSuccessfully = "删除成功";
const openData = "数据开放";
const newKey = "新增密钥";
const apiList = "接口清单";
const zhCN = {
  appSceretKey,
  creationTime,
  status,
  start,
  disable,
  operation,
  "delete": "删除",
  builtIn,
  newSuccessfullyAdded,
  disabledSuccessfully,
  startSuccessfully,
  deleteConfirm,
  deleteSuccessfully,
  openData,
  newKey,
  apiList
};
export {
  apiList,
  appSceretKey,
  builtIn,
  creationTime,
  zhCN as default,
  deleteConfirm,
  deleteSuccessfully,
  disable,
  disabledSuccessfully,
  newKey,
  newSuccessfullyAdded,
  openData,
  operation,
  start,
  startSuccessfully,
  status
};
