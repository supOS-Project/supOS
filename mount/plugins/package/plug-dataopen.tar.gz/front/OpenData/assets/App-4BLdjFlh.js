import { s as supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__-BOZGjbOR.js";
import { s as supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__-BHgn3Pql.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadShare$1("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.25.2"
  } }
}));
const exportModule$5 = await res$5.then((factory) => factory());
var supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__ = exportModule$5;
const { loadShare } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadShare("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$4 = await res$4.then((factory) => factory());
var supos_mf_2_ce_mf_1_OpenData__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$4;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadRemote$3("@supos_host/hooks"));
const exportModule$3 = await initPromise$3.then((_) => res$3);
var supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$3;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadRemote$2("@supos_host/utils"));
const exportModule$2 = await initPromise$2.then((_) => res$2);
var supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule$2;
const baseUrl = "/inter-api/supos";
const api = new supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const querySecretKeyList = async () => api.get("/app/secretKeyList");
const createSecretKey = async () => api.post("/app/secretKey");
const deleteSecretKey = async (id) => api.delete(`/app/secretKey/${id}`);
const updateSecretKey = async (data) => api.put("/app/secretKey", data);
const queryMenuList = async () => api.get("/app/menu/list");
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote$1("@supos_host/button-permission"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__ = exportModule$1;
const { loadRemote } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadRemote("@supos_host/components"));
const exportModule = await initPromise.then((_) => res);
var supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule;
const REMOTE_NAME = "OpenData";
const container = "_container_1xg2b_1";
const demoBox = "_demoBox_1xg2b_9";
const styles$1 = {
  container,
  demoBox
};
const ServerTabs = (props) => {
  const { appSceretKey } = props;
  const formatMessage = supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [activeKey, setActiveKey] = supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.useState("RestAPI");
  const items = [
    {
      key: "RestAPI",
      label: "RestAPI",
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ServerDemo,
        {
          ...typeof supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.demoData.restApi === "function" ? supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.demoData.restApi({ appSceretKey }) : supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.demoData.restApi,
          className: styles$1.demoBox
        }
      )
    },
    {
      key: "websocket",
      label: "websocket",
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ServerDemo, { ...supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.demoData.websocket, className: styles$1.demoBox })
    },
    {
      key: "MQTT",
      label: "MQTT",
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.MqttDemo,
        {
          instanceInfo: {
            dataType: 1,
            topic: "demo",
            fields: [
              {
                name: "timeStamp",
                type: "DATETIME",
                unique: true
              },
              {
                name: "aa",
                type: "DOUBLE"
              },
              {
                name: "quality",
                type: "INT"
              }
            ]
          },
          className: styles$1.demoBox
        }
      )
    }
  ];
  const onChange = (key) => {
    console.log(key);
    setActiveKey(key);
  };
  const handleLink = () => {
    window.open("/swagger-ui/index.html#/");
  };
  const operations = supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.useMemo(() => {
    return activeKey === "RestAPI" ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Button, { type: "primary", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Api, {}), onClick: handleLink, children: formatMessage("apiList") }) : null;
  }, [activeKey]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: styles$1.container, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Tabs,
    {
      activeKey,
      items,
      onChange,
      tabBarExtraContent: operations,
      tabBarStyle: { margin: "0 14px 0" }
    }
  ) });
};
const titleBox = "_titleBox_15t03_1";
const buttonTabs = "_buttonTabs_15t03_7";
const styles = {
  titleBox,
  buttonTabs
};
const OpenData = () => {
  var _a;
  const formatMessage = supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [dataSource, setDataSource] = supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.useState([]);
  const [options, setOptions] = supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.useState([]);
  const { modal } = supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.App.useApp();
  const columns = [
    {
      title: formatMessage("appSceretKey"),
      dataIndex: "appSecretKey",
      render: (text) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Space, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: text }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComCopy, { textToCopy: text })
        ] });
      }
    },
    {
      title: formatMessage("creationTime"),
      dataIndex: "createTime",
      width: "20%",
      render: (txt) => {
        return txt ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(txt) }) : null;
      }
    },
    {
      title: formatMessage("status"),
      dataIndex: "status",
      width: "10%",
      render: (txt) => {
        return txt === 1 ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Tag, { bordered: false, style: { borderRadius: 15 }, color: "green", children: formatMessage("start") }) : /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Tag, { bordered: false, style: { borderRadius: 15 }, color: "magenta", children: formatMessage("disable") });
      }
    },
    {
      title: formatMessage("operation"),
      dataIndex: "operation",
      width: "10%",
      render: (_, record) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Space, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper,
            {
              auth: record.status === 1 ? supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["openData.disable"] : supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["openData.enable"],
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "a",
                {
                  onClick: () => handleToggleDisabled(record),
                  style: {
                    color: "var(--supos-theme-color)"
                  },
                  children: formatMessage(record.status === 1 ? "disable" : "start")
                }
              )
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper, { auth: supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["openData.delete"], children: record.status === 0 && dataSource.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              style: {
                color: "var(--supos-theme-color)"
              },
              onClick: () => handleDelete(record),
              children: formatMessage("delete")
            }
          ) })
        ] });
      }
    }
  ];
  supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.useEffect(() => {
    getDataSource();
  }, []);
  supos_mf_2_ce_mf_1_OpenData__loadShare__react__loadShare__.useEffect(() => {
    queryMenuList().then((data = []) => {
      const newData = [{ label: formatMessage("builtIn"), value: "builtIn" }];
      data.forEach((item) => {
        newData.push({ label: item.appName, value: item.menuUrl, isNewWindow: true });
      });
      setOptions(newData);
    });
  }, []);
  const getDataSource = () => {
    querySecretKeyList().then((data = []) => {
      setDataSource(data);
    });
  };
  const handleAdd = () => {
    createSecretKey().then(() => {
      supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.message.success(formatMessage("newSuccessfullyAdded"));
      getDataSource();
    });
  };
  const handleToggleDisabled = (record) => {
    updateSecretKey({ ...record, status: record.status === 1 ? 0 : 1 }).then(() => {
      supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.message.success(formatMessage(record.status === 1 ? "disabledSuccessfully" : "startSuccessfully"));
      getDataSource();
    });
  };
  const handleDelete = (record) => {
    modal.confirm({
      title: formatMessage("deleteConfirm"),
      onOk: () => {
        deleteSecretKey(record.id).then(() => {
          supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.message.success(formatMessage("deleteSuccessfully"));
          getDataSource();
        });
      }
    });
  };
  const handleSelect = (item) => {
    if (item.isNewWindow) {
      window.open(item.value, "_blank");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading: false, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
    {
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles.titleBox, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_OpenData__loadShare__antd__loadShare__.Space, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.IbmCloudDirectLink_2Dedicated, {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatMessage("openData") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
          {
            auth: supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["openData.addKey"],
            type: "primary",
            icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Add, {}),
            disabled: dataSource.length >= 3,
            onClick: handleAdd,
            children: formatMessage("newKey")
          }
        )
      ] }),
      mustHasBack: false,
      style: {
        display: "flex",
        flexDirection: "column",
        padding: "30px 36px"
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProTable, { columns, dataSource, pagination: false }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_OpenData__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComBtnTabs, { className: styles.buttonTabs, activeKey: "builtIn", options, onSelect: handleSelect }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ServerTabs, { appSceretKey: (_a = dataSource[0]) == null ? void 0 : _a.appSecretKey })
      ]
    }
  ) });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: OpenData
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  OpenData as O,
  jsxRuntimeExports as j
};
