const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/remoteEntry-i4ZhVgSA.js","assets/supos_mf_2_ce_mf_1_OpenData__mf_v__runtimeInit__mf_v__-BHgn3Pql.js","assets/virtualExposes-Bt4deWuj.js","assets/preload-helper-BQEDfpdQ.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-BQEDfpdQ.js";
const remoteEntryPromise = __vitePreload(() => import("./remoteEntry-i4ZhVgSA.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
Promise.resolve(remoteEntryPromise).then((remoteEntry) => {
  return Promise.resolve(remoteEntry.__tla).then(remoteEntry.init).catch(remoteEntry.init);
});
