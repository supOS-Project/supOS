import "./hostInit-DeeSlzv7.js";
import { i as index_cjs, s as supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__-Bw1pIh-H.js";
import { j as jsxRuntimeExports, N as NotificationManagement } from "./App-BExZXD8T.js";
import { s as supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react__loadShare__-B61AXF-M.js";
import { s as supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__-_G0N4dEt.js";
import "./preload-helper-BOasc4QZ.js";
import "./_commonjsHelpers-C7MPfNLY.js";
import "./toConsumableArray-DZoauJau.js";
import "./typeof-DfUwRSCY.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule;
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(NotificationManagement, {}) }) })
);
