const email = "Email";
const dingtalk = "Dingtalk";
const wechat = "WeCom";
const templateCode = "Template Code";
const templateName = "Template Name";
const notificationMethod = "Notification Method";
const description = "Described";
const creationTime = "Creation time";
const operation = "Operation";
const edit = "Edit";
const deleteConfirm = "Are you sure you want to delete it?";
const deleteSuccessfully = "Delete successfully!";
const notificationConfig = "Notification Configuration";
const search = "Search";
const notificationMthodSetting = "Notification Method";
const createNotificationTemplate = "New Notification Template";
const connectSuccess = "Connection is successful";
const serverAddress = "Server Address";
const maxLength = "Maximum length {num}!";
const sslPort = "Port Number";
const required = "Required";
const portRule = "Please enter an integer greater than or equal to 1 and less than or equal to 65535";
const sender = "Sender Address";
const emailRule = "Please enter the correct email address";
const senderPassword = "Sender Password";
const tenantId = "Tenant ID";
const cilentId = "Client ID";
const certificate = "Certificate";
const proxyAddress = "Proxy Address";
const optsuccess = "The operation was successful!";
const sendingServiceType = "Email Server Type";
const fileLimitSize = "Max Attachment Size per Email (MB)";
const timeout = "Timeout Duration (s)";
const connectTest = "Test Connection";
const appName = "Application Name";
const memo = "Remarks";
const companyId = "Enterprise ID";
const templateCodeRule = "Only letters/numbers/underscores are supported";
const content = "Content";
const editNotificationTemplate = "Edit Notification Template";
const timeoutRule = "Please enter an integer greater than or equal to 1 and less than or equal to 60";
const templateConfig = "Template Config";
const themeConfig = "Theme Config";
const themeCode = "Theme Code";
const themeName = "Theme Name";
const linkTemplate = "Associated Template";
const createNotificationTheme = "Create Theme";
const editNotificationTheme = "Edit Theme";
const mail = "Station letter";
const enUS = {
  email,
  dingtalk,
  wechat,
  templateCode,
  templateName,
  notificationMethod,
  description,
  creationTime,
  operation,
  edit,
  "delete": "Delete",
  deleteConfirm,
  deleteSuccessfully,
  notificationConfig,
  search,
  notificationMthodSetting,
  createNotificationTemplate,
  connectSuccess,
  serverAddress,
  maxLength,
  sslPort,
  required,
  portRule,
  sender,
  emailRule,
  senderPassword,
  tenantId,
  cilentId,
  certificate,
  proxyAddress,
  optsuccess,
  sendingServiceType,
  fileLimitSize,
  timeout,
  connectTest,
  appName,
  memo,
  companyId,
  templateCodeRule,
  content,
  editNotificationTemplate,
  timeoutRule,
  templateConfig,
  themeConfig,
  themeCode,
  themeName,
  linkTemplate,
  createNotificationTheme,
  editNotificationTheme,
  mail
};
export {
  appName,
  certificate,
  cilentId,
  companyId,
  connectSuccess,
  connectTest,
  content,
  createNotificationTemplate,
  createNotificationTheme,
  creationTime,
  enUS as default,
  deleteConfirm,
  deleteSuccessfully,
  description,
  dingtalk,
  edit,
  editNotificationTemplate,
  editNotificationTheme,
  email,
  emailRule,
  fileLimitSize,
  linkTemplate,
  mail,
  maxLength,
  memo,
  notificationConfig,
  notificationMethod,
  notificationMthodSetting,
  operation,
  optsuccess,
  portRule,
  proxyAddress,
  required,
  search,
  sender,
  senderPassword,
  sendingServiceType,
  serverAddress,
  sslPort,
  templateCode,
  templateCodeRule,
  templateConfig,
  templateName,
  tenantId,
  themeCode,
  themeConfig,
  themeName,
  timeout,
  timeoutRule,
  wechat
};
