const email = "邮箱";
const dingtalk = "钉钉";
const wechat = "企业微信";
const templateCode = "模板编码";
const templateName = "模板名称";
const notificationMethod = "通知方式";
const description = "描述";
const creationTime = "创建时间";
const operation = "操作";
const edit = "编辑";
const deleteConfirm = "您确认要删除吗？";
const deleteSuccessfully = "删除成功！";
const notificationConfig = "消息配置";
const search = "搜索";
const notificationMthodSetting = "通知方式设置";
const createNotificationTemplate = "创建消息模板";
const connectSuccess = "连接成功";
const serverAddress = "服务器地址";
const maxLength = "最大长度{num}！";
const sslPort = "端口";
const required = "必填项";
const portRule = "请输入大于等于1小于等于65535的整数";
const sender = "发件人";
const emailRule = "请输入正确的邮箱格式";
const senderPassword = "发件人密码";
const tenantId = "租户ID";
const cilentId = "客户端ID";
const certificate = "证书";
const proxyAddress = "代理人地址";
const optsuccess = "操作成功!";
const sendingServiceType = "发送服务类型";
const fileLimitSize = "单封邮件附件容量（M）";
const timeout = "超时时间（s）";
const connectTest = "测试连接";
const appName = "应用名称";
const memo = "备注";
const companyId = "企业ID";
const templateCodeRule = "仅支持字母/数字/下划线";
const content = "内容";
const editNotificationTemplate = "编辑消息模板";
const timeoutRule = "请输入大于等于1小于等于60的整数";
const templateConfig = "模板配置";
const themeConfig = "主题配置";
const themeCode = "主题编码";
const themeName = "主题名称";
const linkTemplate = "关联模板";
const createNotificationTheme = "创建消息主题";
const editNotificationTheme = "编辑消息主题";
const mail = "站内信";
const zhCN = {
  email,
  dingtalk,
  wechat,
  templateCode,
  templateName,
  notificationMethod,
  description,
  creationTime,
  operation,
  edit,
  "delete": "删除",
  deleteConfirm,
  deleteSuccessfully,
  notificationConfig,
  search,
  notificationMthodSetting,
  createNotificationTemplate,
  connectSuccess,
  serverAddress,
  maxLength,
  sslPort,
  required,
  portRule,
  sender,
  emailRule,
  senderPassword,
  tenantId,
  cilentId,
  certificate,
  proxyAddress,
  optsuccess,
  sendingServiceType,
  fileLimitSize,
  timeout,
  connectTest,
  appName,
  memo,
  companyId,
  templateCodeRule,
  content,
  editNotificationTemplate,
  timeoutRule,
  templateConfig,
  themeConfig,
  themeCode,
  themeName,
  linkTemplate,
  createNotificationTheme,
  editNotificationTheme,
  mail
};
export {
  appName,
  certificate,
  cilentId,
  companyId,
  connectSuccess,
  connectTest,
  content,
  createNotificationTemplate,
  createNotificationTheme,
  creationTime,
  zhCN as default,
  deleteConfirm,
  deleteSuccessfully,
  description,
  dingtalk,
  edit,
  editNotificationTemplate,
  editNotificationTheme,
  email,
  emailRule,
  fileLimitSize,
  linkTemplate,
  mail,
  maxLength,
  memo,
  notificationConfig,
  notificationMethod,
  notificationMthodSetting,
  operation,
  optsuccess,
  portRule,
  proxyAddress,
  required,
  search,
  sender,
  senderPassword,
  sendingServiceType,
  serverAddress,
  sslPort,
  templateCode,
  templateCodeRule,
  templateConfig,
  templateName,
  tenantId,
  themeCode,
  themeConfig,
  themeName,
  timeout,
  timeoutRule,
  wechat
};
