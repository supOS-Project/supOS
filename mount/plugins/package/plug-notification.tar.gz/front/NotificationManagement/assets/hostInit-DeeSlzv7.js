const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/remoteEntry-BK2lYb-Z.js","assets/supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__-Bw1pIh-H.js","assets/virtualExposes-v-3Y1odB.js","assets/preload-helper-BOasc4QZ.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-BOasc4QZ.js";
const remoteEntryPromise = __vitePreload(() => import("./remoteEntry-BK2lYb-Z.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
Promise.resolve(remoteEntryPromise).then((remoteEntry) => {
  return Promise.resolve(remoteEntry.__tla).then(remoteEntry.init).catch(remoteEntry.init);
});
