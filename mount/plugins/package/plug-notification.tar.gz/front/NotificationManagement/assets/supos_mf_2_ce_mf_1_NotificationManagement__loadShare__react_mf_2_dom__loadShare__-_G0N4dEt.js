import { g as getDefaultExportFromCjs } from "./_commonjsHelpers-C7MPfNLY.js";
import { s as supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__-Bw1pIh-H.js";
function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== "string" && !Array.isArray(e)) {
      for (const k in e) {
        if (k !== "default" && !(k in n)) {
          const d = Object.getOwnPropertyDescriptor(e, k);
          if (d) {
            Object.defineProperty(n, k, d.get ? d : {
              enumerable: true,
              get: () => e[k]
            });
          }
        }
      }
    }
  }
  return Object.freeze(Object.defineProperty(n, Symbol.toStringTag, { value: "Module" }));
}
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_NotificationManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("react-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^18.3.1"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__ = exportModule;
const ReactDOM = /* @__PURE__ */ getDefaultExportFromCjs(supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__);
const ReactDOM$1 = /* @__PURE__ */ _mergeNamespaces({
  __proto__: null,
  default: ReactDOM
}, [supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__]);
export {
  ReactDOM as R,
  ReactDOM$1 as a,
  supos_mf_2_ce_mf_1_NotificationManagement__loadShare__react_mf_2_dom__loadShare__ as s
};
